﻿using System.Data;
using System.Security.Claims;
using Katalitica_API.Models;
using Katalitica_API.Resources;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Katalitica_API.Controllers
{

    [ApiController]
    [Route("company")]
    public class CompanyController : ControllerBase
	{
       

        [HttpGet]
        [Route("getAllCompanies")]
        public dynamic getAllCompanies()
        {
            DataSet companies = DBDatos.ListarTablas("sp_getAllFromGeneralesCompanias");
            Console.WriteLine(companies);
            string jsonCompany = JsonConvert.SerializeObject(companies);

            return new
            {
                success = true,
                message = "Company found",
                result = jsonCompany
            };
        }

        [HttpPost]
        [Route("postCompany")]
        public dynamic postCompany(
        string clave_compania,
        string rfc,
        string razon_social,
        string nombre_corto,
        string nombre_largo,
        string calle,
        string colonia,
        string estado,
        string codigo_postal,
        string contacto_persona,
        string telefono)
        {            
            List<ParameterResource> parameters = new List<ParameterResource>
            {
                new ParameterResource("@clave_compania", clave_compania),
                new ParameterResource("@rfc", rfc),
                new ParameterResource("@razon_social", razon_social),
                new ParameterResource("@nombre_corto", nombre_corto),
                new ParameterResource("@nombre_largo", nombre_largo),
                new ParameterResource("@calle", calle),
                new ParameterResource("@colonia", colonia),
                new ParameterResource("@estado", estado),
                new ParameterResource("@codigo_postal", codigo_postal),
                new ParameterResource("@contacto_persona", contacto_persona),
                new ParameterResource("@telefono", telefono)
            };

            bool queryExecuted = DBDatos.Ejecutar("sp_insertIntoGeneralesCompanias", parameters);
            if (queryExecuted)
            {
                return new
                {
                    success = queryExecuted,
                    message = "Company registered",
                };
            }
            else {
                return new
                {
                    success = false,
                    message = "Company not registered",
                };
            }

            
        }


        [HttpGet]
        [Route("getCompanyById")]
        public dynamic getCompanyById(string id)

        {
            List<ParameterResource> parameter = new  List<ParameterResource>{
                new ParameterResource("@Id", id)
            };

           DataTable companies = DBDatos.Listar("sp_getFromGeneralesCompaniasById", parameter);
            Console.WriteLine(companies);
           string jsonCompany = JsonConvert.SerializeObject(companies);
           


            return new
            {
                success = true,
                message = "Success",
                result = new
                {
                    company = jsonCompany
                }
            };


        }

        [HttpDelete]
        [Route("deleteCompanyById")]
        [Authorize]
        public dynamic deleteCompanyById(string id)
        {
            List<ParameterResource> parameter = new List<ParameterResource>{
                new ParameterResource("@Id", id)
            };

            var identity = HttpContext.User.Identity as ClaimsIdentity;

            var rToken = Jwt.ValidateToken(identity);
            

            if (!rToken.success)
            {
                return rToken;
            }

            UserModel _user = rToken.result;

            if(_user.userType != 1)
            {
                return new
                {
                    sucess = false,
                    message = "Cant delete company. Only admin users can.",
                };
            }

            bool queryExecuted = DBDatos.Ejecutar("sp_deleteFromGeneralesCompaniaById", parameter);

            return new
            {
                success = queryExecuted,
           
            };

        }


    }
}

