﻿namespace Identity
{
    public class ModulesHierachy
    {
        public string? Name { get; set; }
        public string? Path { get; set; }
        public string? rootPath { get; set; }
    }
}
