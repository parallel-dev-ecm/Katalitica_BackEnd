﻿using System;
namespace Katalitica_API.Controllers
{
	public class ParameterResource
	{
		public ParameterResource(string name, string value)
		{
			Name = name;
			Valor = value;
		}
		public string Name { get; set; }


        public string Valor { get; set; }




    }
}

